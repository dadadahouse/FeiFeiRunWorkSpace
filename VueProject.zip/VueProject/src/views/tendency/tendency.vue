<template>
	<div>		
		<!-- 搜索筛选 -->
		<el-form :inline="true" :model="queryDto" class="user-search">
			<el-form-item label="">
				<appSelect v-bind:query-dto="queryDto"></appSelect>
			</el-form-item>	
			<el-form-item label="">
				<channelSelect v-bind:query-dto="queryDto"></channelSelect>
			</el-form-item>		
			<el-form-item>
				<el-button type="primary"  icon="el-icon-search">搜索</el-button>				
			</el-form-item>			
		</el-form>
		
		<el-card class="box-card">
			<div slot="header" class="clearfix">
				<span>数据详情</span>
				<el-button type="mini" style="float:right" @click="dialogVisible = true">新增趋势模板</el-button>
			</div>
			<div class="text item">
				<!--列表-->
				<el-table :data="pageInfo.list" highlight-current-row v-loading="loading" border element-loading-text="拼命加载中" style="width: 100%;">
					<el-table-column :fixed="true" sortable prop="name" label="模板名称" width="110">
					</el-table-column>	
					<el-table-column :fixed="true" sortable prop="appName" label="游戏名称" width="130">
					</el-table-column>			
					<el-table-column :fixed="true" sortable prop="channelName" label="渠道名称" width="130">
					</el-table-column>
					<el-table-column sortable prop="beginDate" label="开始时间" width="110">
						<template slot-scope="scope">
							<div>{{ getDate(new Date(scope.row.beginDate)) }}</div>
						</template>
					</el-table-column>
					<el-table-column sortable prop="endDate" label="结束时间" width="110">
						<template slot-scope="scope">
							<div>{{ getDate(new Date(scope.row.endDate)) }}</div>
						</template>
					</el-table-column>
					<el-table-column sortable prop="lastKeepRate" label="最终留存率" width="130">						
						<template slot-scope="scope">
							<div v-if="scope.row.lastKeepRate != null">{{ scope.row.lastKeepRate }}</div>
							<div v-if="scope.row.lastKeepRate == null">-</div>
						</template>
					</el-table-column>					
					<el-table-column sortable prop="keepDetail" label="留存趋势">	
						<template slot="header" slot-scope="scope">
							<div>留存趋势</div>
							<el-tooltip class="item" effect="dark" content="每日留存人数趋势" placement="top-start">
								<div><i class="el-icon-question"></i></div>
							</el-tooltip>
						</template>
						<template slot-scope="scope">
							<el-button type="text" @click="getLineChart(scope, scope.row.keepDetail, '人')" icon="iconfont icon-line-chart"></el-button>
						</template>
					</el-table-column>										
					<el-table-column label="留存率衰减趋势">	
						<template slot="header" slot-scope="scope">
							<div>留存率衰减趋势</div>
							<el-tooltip class="item" effect="dark" content="每日留存比率相对于前一天的衰减度" placement="top-start">
								<div><i class="el-icon-question"></i></div>
							</el-tooltip>
						</template>
						<template slot-scope="scope">
							<el-button type="text" @click="getLineChart(scope, scope.row.keepDecay, '%')" icon="iconfont icon-line-chart"></el-button>
						</template>
					</el-table-column>
					<el-table-column sortable prop="activePayDecay" label="活跃用户付费率衰减趋势" width="230">
						<template slot="header" slot-scope="scope">
							<div>活跃用户付费率衰减趋势</div>
							<el-tooltip class="item" effect="dark" content="每日活跃用户付费率相对于前一天的衰减度" placement="top-start">
								<div><i class="el-icon-question"></i></div>
							</el-tooltip>
						</template>
						<template slot-scope="scope">
							<el-button type="text" @click="getLineChart(scope, scope.row.activePayDecay, '%')" icon="iconfont icon-line-chart"></el-button>
						</template>
					</el-table-column>					
				</el-table>
				<!-- 分页组件 -->
				<Pagination v-bind:child-msg="pageInfo" @callFather="page"></Pagination>
			</div>
		</el-card>
		
		<el-dialog :title="lineDialog.title" :visible.sync="lineDialog.visible" width="40%">
			<div id="chart-container" style="height: 400px;width:100%"></div>
		</el-dialog>
		
		<el-dialog title="新增LTV趋势图" :visible.sync="dialogVisible" custom-class="customDialog">
			<el-form :model="tendencyDto" ref="addTendency" :rules="paramRules" class="user-search" label-width="20%">
				<el-form-item label="日期" prop="date">
					<el-date-picker v-model="tendencyDto.date" type="daterange"
					  align="right"  unlink-panels value-format="yyyy-MM-dd"
					  range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
					</el-date-picker>
				</el-form-item>	
				<el-form-item label="模板名称" prop="name">
					<el-input style="width:48%" v-model="tendencyDto.name" placeholder="模板名称"></el-input>
				</el-form-item>	
				<el-form-item label="游戏" prop="appId">
					<appSelect v-bind:query-dto="tendencyDto"></appSelect>
				</el-form-item>	
				<el-form-item label="渠道" prop="channelId">
					<channelSelect v-bind:query-dto="tendencyDto"></channelSelect>
				</el-form-item>	
				<el-form-item label="最终留存率" prop="lastKeepRate">
					<el-input style="width:48%" v-model="tendencyDto.lastKeepRate" placeholder="最终留存率">
						<template slot="append">%</template>
					</el-input>
				</el-form-item>				
			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="dialogVisible = false">取 消</el-button>
				<el-button v-loading="tendencyDto.btnLoading" type="primary" @click="addLtvTendency">确 定</el-button>
			</span>
		</el-dialog>
		
	</div>
</template>

<script>
import Pagination from '../../components/Pagination'
import appSelect from '../../components/appSelect'
import channelSelect from '../../components/channelSelect'
import * as tendencyApi from '../../api/tendencyApi'
import $echarts from 'echarts'

export default {
	components: {
		/**注册组件*/
		Pagination,
		appSelect,         
		channelSelect
	},
	data() {
		var validateDate = (rule, value, callback) => {
			if (value === '' || value.length < 2) {
				callback(new Error('请选择查询日期'));
			} else {
				callback();
			}
		};
		return {
			pageInfo: {
				currentPage: 1,
				pageSize: 10,
				total: 10,
				list: []
			},			
			queryDto: {
				appId: '',
				channelId:''
			},
			tendencyDto: {
				btnLoading: false,
				name: '',
				date: [],
				appId: '',
				channelId: '',
				lastKeepRate: ''   //最终留存率 选填
			},
			loading: false,	
			dialogVisible:false,
			lineDialog:{
				visible: false,
				title: '趋势图'
			},
			paramRules: {
				date: [{ validator: validateDate, trigger: 'change' }],
				name: [{ required: true, message: '请输入模板名称', trigger: 'blur' }],
				appId: [{ required: true, message: '请选择游戏', trigger: 'change' }],
				channelId: [{ required: true, message: '请选择渠道', trigger: 'change' }]
			}
		}
	},
	methods: {
		init(){
			this.getData();
		},
		getData(){
			var param = {
				page: this.pageInfo.currentPage,
				pageSize: this.pageInfo.pageSize,
				appId: this.queryDto.appId,
				channelId: this.queryDto.channelId
			};
			tendencyApi.page(param).then(response => {
				this.loading = false
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.pageInfo.list = response.data.list;
					// 分页赋值
					this.pageInfo.currentPage = response.data.pageNum;
					this.pageInfo.pageSize = response.data.pageSize;
					this.pageInfo.total = response.data.total;
				}
			}).catch(err => {
				this.loading = false
				this.$message.error('数据加载失败，请稍后再试！')
			})
		},
		page(param){
			this.pageInfo.currentPage = param.currentPage;
			this.pageInfo.pageSize = param.pageSize;
			this.getData();	
		},
		addLtvTendency(){
			this.tendencyDto.btnLoading = true;
			this.$refs['addTendency'].validate((valid) => {
				if(!valid) {
					this.tendencyDto.btnLoading = false;
					return false;
				}
				var param = {
					name: this.tendencyDto.name,
					appId: this.tendencyDto.appId,
					channelId: this.tendencyDto.channelId,
					beginDate: this.tendencyDto.date[0],
					endDate: this.tendencyDto.date[1],
					lastKeepRate: this.tendencyDto.lastKeepRate
				}
				tendencyApi.addLtv(param).then(response => {
					this.tendencyDto.btnLoading = false;
					if (response.code != 0) {
						this.$message.info(response.msg);
					} else {
						this.$message.success("添加趋势模板成功");
						this.dialogVisible = false;
						this.getData();
					}
				}).catch(err => {
					this.tendencyDto.btnLoading = false;
					this.$message.error('数据加载失败，请稍后再试！')
				})
			});
		},
		getLineChart(scope, val, unit){
		
			var row = scope.row;
			var json = JSON.parse(val);
			var node = [];
			var data = [];
			json.forEach((item, i) => {
				var date = new Date(item.day);
				node.push(this.getDate(date));
				data.push(item.decay);
			});
			
			
			
			let option = {
				tooltip: { trigger: 'axis' },
				toolbox: {
					feature: { saveAsImage: {} }
				},
				xAxis: {
					type: 'category',
					data: node
				},
				yAxis: {
					type: 'value',
					axisLabel: {
						formatter: '{value} (' + unit + ')'
					}
				},
				series: [{
					data: data,
					type:'line',
					symbol: 'none',	
					markLine: {
			　　　　　　data : [
			　　　　　　　　{type : 'average', name: '平均值'}
			　　　　　　]
			　　　　} 
				}]
			};
			
			this.lineDialog.title = scope.column.label;
			this.lineDialog.visible = true;	
			setTimeout(function(){
				// 基于准备好的dom，初始化echarts实例
				let $chart = $echarts.init(document.getElementById('chart-container'));					
				// 绘制图表
				$chart.setOption(option);
			}, 300);
		},
		getLtvLineChart(scope, val){
			var row = scope.row;
			var json = JSON.parse(val);
			var node = [];
			var data = [];
			node.push(this.getDate(new Date(row.beginDate)));
			data.push(1);
			json.forEach((item, i) => {
				var date = new Date(row.beginDate); 
				date.setDate(date.getDate() + item.day);
				node.push(this.getDate(date));
				data.push(item.decay);
			});
			
			
			let option = {
				tooltip: { trigger: 'axis' },
				toolbox: {
					feature: { saveAsImage: {} }
				},
				xAxis: {
					type: 'category',
					data: node
				},
				yAxis: {
					type: 'value'
				},
				series: [{
					data: data,
					type: 'line'
				}]
			};
			this.lineDialog.title = scope.column.label;
			this.lineDialog.visible = true;	
			setTimeout(function(){
				// 基于准备好的dom，初始化echarts实例
				let $chart = $echarts.init(document.getElementById('chart-container'));					
				// 绘制图表
				$chart.setOption(option);
			}, 300);
		},
	},	
	created() {
		this.init();
	}	  
}
</script>

<style scoped>
.user-search {
  margin-top: 20px;
}
.userRole {
  width: 100%;
}
.cell {
	text-align: center !important
}
.customDialog {
	width: 30%;
	min-width: 500px;
}
</style>

<style>
.customDialog {
	width: 30%;
	min-width: 500px;
}
.el-table th div {
	line-height: 12px !important;
}
.el-table .cell, .el-table th div {
	padding: 0px 4px !important;
}
</style>

 
 