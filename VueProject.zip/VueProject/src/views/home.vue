/**首页*/
<template>
	<div>
		<div class="element-panel">
			<el-card class="element-col">
				<div class="element-body">
					<div>
						<span class="normal">{{platformData.activeUsers}}</span>
						<span class="light">活跃用户数</span>
					</div>
					<div class="icon-muted">
						<i class="iconfont icon-people"></i>
					</div>
				</div>
			</el-card>
			<el-card class="element-col">
				<div class="element-body">
					<div>
						<span class="normal">{{platformData.newIncreaseUsers}}</span>
						<span class="light">新增用户数</span>
					</div>
					<div class="icon-muted">
						<i class="iconfont icon-people"></i>
					</div>
				</div>
			</el-card>
			<el-card class="element-col">
				<div class="element-body">
					<div>
						<span class="normal">{{platformData.newIncreaseRechargeUsers}}</span>
						<span class="light">新增充值用户数</span>
					</div>
					<div class="icon-muted">
						<i class="iconfont icon-people"></i>
					</div>
				</div>
			</el-card>
			<el-card class="element-col">
				<div class="element-body">
					<div>
						<span class="normal">{{platformData.totalMoneys}}</span>
						<span class="light">充值总数</span>
					</div>
					<div class="icon-muted">
						<i class="iconfont icon-wallet"></i>
					</div>
				</div>
			</el-card>
			
		</div>
		
		<div class="panel">
			<el-card class="panel-col">
				<div slot="header" class="col-header">
					<span>今日游戏数据</span>					
				</div>
				<div class="col-body">
					<!--列表-->
					<el-table  height="350" :data="pageInfo.list" highlight-current-row v-loading="pageInfo.loading" border element-loading-text="拼命加载中" style="width: 100%;">
						<el-table-column prop="appName" label="游戏" width="110">
						</el-table-column>			
						<el-table-column prop="channelName" label="渠道" width="100">
						</el-table-column>
						<el-table-column sortable prop="basicData.activeUsers" label="活跃用户" width="120">
						</el-table-column>
						<el-table-column sortable prop="basicData.newIncreaseUsers" label="新增用户" width="120">
						</el-table-column>
						<el-table-column sortable prop="basicData.newIncreaseRechargeUsers" label="新增充值用户" width="130">
						</el-table-column>						
						<el-table-column sortable prop="basicData.totalMoneys" label="充值总数" width="120">
						</el-table-column>
					</el-table>
					<!-- 分页组件 -->
					<Pagination v-bind:child-msg="pageInfo" @callFather="page"></Pagination>
				</div>
			</el-card>
			
				
			<el-card class="panel-col">
				<div slot="header" class="col-header">
					<span>玩家等级分布</span>					
				</div>
				<div id="level-chart-container" class="col-body">
					
				</div>
			</el-card>				
		</div>
		<div class="panel">
			<el-card class="panel-col" v-if="definedRoiList == null || definedRoiList.length == 0">
				<div slot="header" class="col-header">
					<span>自定义看板</span>	
					<div class="col-option">
						<i class="el-icon-setting" @click="definedRoi.dialogVisible = true;"/>
					</div>
				</div>
				<div class="col-body">
					
				</div>
			</el-card>
			<el-card class="panel-col" :id="'defined-roi-' + i" v-for="(item, i) of definedRoiList" v-if="definedRoiList != null && definedRoiList.length > 0">
				<div slot="header" class="col-header">
					<span>自定义看板</span>	
					<div class="col-option">
						<i class="el-icon-setting" @click="definedRoi.dialogVisible = true;"/>
					</div>
				</div>
				<div class="col-body">
					
				</div>
			</el-card>
		</div>
		
		<el-dialog title="自定义ROI" :visible.sync="definedRoi.dialogVisible" width="30%">
			<el-form :model="definedRoi" ref="addTendency"  class="user-search" label-width="20%">
				<el-form-item label="起始日期">
					<el-date-picker v-model="definedRoi.date" type="daterange"
						align="right"  unlink-panels value-format="yyyy-MM-dd"
						range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
					</el-date-picker>
				</el-form-item>
				<el-form-item label="游戏" prop="appId">
					<appSelect v-bind:query-dto="definedRoi"></appSelect>
				</el-form-item>	
				<el-form-item label="渠道" prop="channelId">
					<channelSelect v-bind:query-dto="definedRoi" v-bind:multiple="true"></channelSelect>
				</el-form-item>	
				<el-form-item label="设备成本" prop="deviceCost">
					<el-input style="width:48%" v-model="definedRoi.deviceCost" placeholder="设备成本(若不填则取投放数据)"></el-input>
				</el-form-item>
			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="definedRoi.dialogVisible = false">取 消</el-button>
				<el-button type="primary" v-loading="definedRoi.btnLoading" @click="getdefinedRoi">确 定</el-button>
			</span>
		</el-dialog>
	</div>		
</template>
<script type="text/ecmascript-6">
import Pagination from '../components/Pagination'
import channelSelect from '../components/channelSelect'
import appSelect from '../components/appSelect'
import $echarts from 'echarts'
import * as homeApi from '../api/homeApi'
export default {
	components: {
		/**注册组件*/
		Pagination,
		appSelect,
		channelSelect
	},
	data(){
		return {
			platformData: {			//基础数据
				activeUsers: 0,
				newIncreaseUsers: 0,
				newIncreaseRechargeUsers: 0,
				totalMoneys: 0
			},   
			pageInfo: {
				currentPage: 1,
				pageSize: 10,
				total: 10,
				list: [],
				loading: false
			},
			definedRoi: {
				btnLoading: false,
				dialogVisible: false,
				appId: '',
				channelId: '',
				date: [],
				deviceCost: ''
			},
			definedRoiList: []
		}
	},
	methods:{
		init: function(){
			this.getBasicData();
			this.getAppBasic();
			this.initLevel();
			this.initdefinedRoiPanel();
		},
		getBasicData:function(){
			//初始化顶部基础数据
			homeApi.getBasic().then(response => {
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					if(response.data){
						this.platformData = response.data
					}
				}
			}).catch(err => {
				this.$message.error('数据加载失败，请稍后再试！')
			});
		},
		getAppBasic: function(){
			var param = {
				page: this.pageInfo.currentPage,
				pageSize: this.pageInfo.pageSize				
			};
			homeApi.appBasic(param).then(response => {
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.pageInfo.list = response.data.list;
					// 分页赋值
					this.pageInfo.currentPage = response.data.pageNum;
					this.pageInfo.pageSize = response.data.pageSize;
					this.pageInfo.total = response.data.total;
				}
			}).catch(err => {
				this.$message.error('数据加载失败，请稍后再试！')
			});
		},
		page(){
		
		},
		initLevel: function(){
			var option = {
				title : {x:'center'},
				tooltip : {trigger: 'item',formatter: "{a} <br/>{b} : {c} ({d}%)"},
				legend: {
					orient: 'vertical',
					left: 'left',
					data: ['0-10','10-20','20-30','30-40','40-50','50-60','60-70','70-80']
				},
				series : [
					{
						name: '等级',
						type: 'pie',
						radius : '70%',
						center: ['50%', '60%'],
						data:[
							{value:135, name:'0-10'},
							{value:310, name:'10-20'},
							{value:234, name:'20-30'},
							{value:335, name:'30-40'},
							{value:548, name:'40-50'},
							{value:948, name:'50-60'},
							{value:1548, name:'60-70'},
							{value:251, name:'70-80'},
						],
						itemStyle: {
							emphasis: {
								shadowBlur: 10,
								shadowOffsetX: 0,
								shadowColor: 'rgba(0, 0, 0, 0.5)'
							}
						}
					}
				]
			};

			let $chart = $echarts.init(document.getElementById('level-chart-container'));					
			$chart.setOption(option);
		},
		getdefinedRoi(){
			this.definedRoi.btnLoading = true;
			var param = {
				appId: this.definedRoi.appId,
				channelIds: this.definedRoi.channelId.join(','),
				beginDay: this.definedRoi.date[0],
				endDay: this.definedRoi.date[1],
				deviceCost: this.definedRoi.deviceCost
			}
			homeApi.definedRoi(param).then(response => {
				this.definedRoi.btnLoading = false
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {					
					this.definedRoiList.unshift(response.data);				
					
					sessionStorage.setItem("definedRoiChart", JSON.stringify(this.definedRoiList));
					
					this.definedRoi.dialogVisible = false;
					this.initdefinedRoiPanel();
				}
			}).catch(error => {
				console.error(error);
				this.definedRoi.btnLoading = false
				this.$message.error('数据加载失败，请稍后再试！')
			})
		},
		initdefinedRoiPanel(){
			var content = sessionStorage.getItem("definedRoiChart");
			if(content){
				var $this = this;
				$this.definedRoiList = JSON.parse(content);
				setTimeout(function(){
					$this.definedRoiList.forEach(function(item, i) {
						let $chart = $echarts.init(document.querySelector('#defined-roi-' + i + " .col-body"));					
						
						$chart.setOption(item);
					});			
				}, 300);
			}
		}
	},
	mounted() {
		var _this = this;
		setTimeout(function(){
			_this.init();
		}, 1000);
	}
}
</script>
<style>
body {
	background-color:#EFEFEF !important;
}
</style>
<style scoped>
.element-panel {
	width: 100%;
}
.element-col {
	width: 22%;
	height: 110px;
	margin: 0 1%;
	float:left;
}

.element-body {
	-webkit-box-align: center!important;
    -ms-flex-align: center!important;
    align-items: center!important;
	-webkit-box-pack: justify!important;
    -ms-flex-pack: justify!important;
    justify-content: space-between!important;
	display: -webkit-box!important;
    display: -ms-flexbox!important;
    display: flex!important;
	-webkit-box-flex: 1;
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 1rem;
}
.normal {
    font-weight: 400!important;
	margin-bottom: .5rem!important;
	display: block!important;
	font-size: 1.3125rem;
}
.light {
    font-weight: 300!important;
}
.icon-muted {
	color: #999!important;
}
.icon-muted i{
	font-size: 32px;
}
.panel {
	width:48.6%;
	float:left;
	margin-top: 20px;
}
.panel-col {
	width: 96%;
	margin: 1%;
	float:left;
}
.col-header {
	font-size: 13px;
}
.col-body {
	height: 400px;
}
.col-option{
	float:right;
}
.col-option i {
	font-size:20px;
	color: #98A7C6;
}

</style>