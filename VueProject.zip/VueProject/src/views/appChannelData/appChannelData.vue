<template>
	<div>		
		<!-- 搜索筛选 -->
		<el-form :inline="true" :model="queryDto" class="user-search">
			<el-form-item label="">
				<el-date-picker v-model="queryDto.date" type="daterange"
				  align="right"  unlink-panels value-format="yyyy-MM-dd"
				  range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
				</el-date-picker>
			</el-form-item>	
			<el-form-item label="">
				<appSelect v-bind:query-dto="queryDto"></appSelect>
			</el-form-item>	
			<el-form-item label="">
				<channelSelect v-bind:query-dto="queryDto"></channelSelect>
			</el-form-item>					
			<el-form-item>
				<el-button type="primary" @click="getData" icon="el-icon-search">搜索</el-button>				
			</el-form-item>			
		</el-form>
		
		<el-card class="box-card">
			<div slot="header" class="clearfix">
				<span>数据详情</span>
				<targetSelect ref="targetSelect" @callFather="selectTarget" style="float:right"></targetSelect>		
			</div>
			<div class="text item">
				<!--列表-->
				<el-table :data="pageInfo.list" highlight-current-row v-loading="loading" border element-loading-text="拼命加载中" style="width: 100%;">
					<el-table-column :fixed="true" sortable prop="appName" label="游戏名称" width="130">						
					</el-table-column>			
					<el-table-column :fixed="true" sortable prop="channelName" label="渠道名称" width="130">						
					</el-table-column>
					<el-table-column :fixed="true" sortable prop="date" label="日期" width="100">
					</el-table-column>
					<el-table-column sortable prop="basicData.newIncreaseRoles" label="新增角色数" width="130">
					</el-table-column>
					<el-table-column sortable prop="basicData.newIncreaseRechargeUsers" label="新增付费用户数" width="200">
						<template slot="header" slot-scope="scope">
							<div>新增付费用户数</div>
							<el-tooltip class="item" effect="dark" content="首充用户数" placement="top-start">
								<div><i class="el-icon-question"></i></div>
							</el-tooltip>
						</template>
					</el-table-column>
					<el-table-column sortable prop="basicData.newIncreaseRolesMoneys" label="新增用户付费金额" width="200">
						<template slot="header" slot-scope="scope">
							<div>新增用户付费金额</div>
							<el-tooltip class="item" effect="dark" content="首充总金额" placement="top-start">
								<div><i class="el-icon-question"></i></div>
							</el-tooltip>
						</template>
					</el-table-column>
					<el-table-column sortable prop="basicData.newIncreaseUsers" label="新增用户数" width="130">
					</el-table-column>
					<el-table-column sortable label="新增用户ARPU" width="180">
						<template slot="header" slot-scope="scope">
							<div>新增用户ARPU</div>
							<el-tooltip class="item" effect="dark" content="新增用户付费金额/新增用户数" placement="top-start">
								<div><i class="el-icon-question"></i></div>
							</el-tooltip>
						</template>
						<template slot-scope="scope">
								<div v-if="scope.row.basicData.newIncreaseUsers != 0">{{(scope.row.basicData.newIncreaseRolesMoneys / scope.row.basicData.newIncreaseUsers).toFixed(2)}}</div>
								<div v-if="scope.row.basicData.newIncreaseUsers == 0">0</div>
						</template>
					</el-table-column>
					<el-table-column sortable label="新增ARPPU" width="170">
						<template slot="header" slot-scope="scope">
							<div>新增ARPPU</div>
							<el-tooltip class="item" effect="dark" content="新增用户付费金额/新增付费用户数" placement="top-start">
								<div><i class="el-icon-question"></i></div>
							</el-tooltip>
						</template>
						<template slot-scope="scope">
								<div v-if="scope.row.basicData.newIncreaseRechargeUsers != 0">{{(scope.row.basicData.newIncreaseRolesMoneys / scope.row.basicData.newIncreaseRechargeUsers).toFixed(2)}}</div>
								<div v-if="scope.row.basicData.newIncreaseRechargeUsers == 0">0</div>
						</template>
					</el-table-column>
					
					<el-table-column sortable prop="basicData.activeUsers" label="活跃用户数" width="130">
					</el-table-column>
					<el-table-column sortable prop="basicData.rechargeUsers" label="活跃付费用户数" width="150">
					</el-table-column>
					<el-table-column sortable prop="basicData.totalMoneys" label="总付费金额" width="130">
					</el-table-column>					
					<el-table-column sortable label="活跃ARPU" width="150">
						<template slot="header" slot-scope="scope">
							<div>活跃ARPU</div>
							<el-tooltip class="item" effect="dark" content="总付费数/活跃用户数" placement="top-start">
								<div><i class="el-icon-question"></i></div>
							</el-tooltip>
						</template>
						<template slot-scope="scope">
								<div v-if="scope.row.basicData.activeUsers != 0">{{(scope.row.basicData.totalMoneys / scope.row.basicData.activeUsers).toFixed(2)}}</div>
								<div v-if="scope.row.basicData.activeUsers == 0">0</div>
						</template>
					</el-table-column>
					<el-table-column sortable label="活跃ARPPU" width="170">
						<template slot="header" slot-scope="scope">
							<div>活跃ARPPU</div>
							<el-tooltip class="item" effect="dark" content="总付费数/付费用户数" placement="top-start">
								<div><i class="el-icon-question"></i></div>
							</el-tooltip>
						</template>
						<template slot-scope="scope">
								<div v-if="scope.row.basicData.rechargeUsers != 0">{{(scope.row.basicData.totalMoneys / scope.row.basicData.rechargeUsers).toFixed(2)}}</div>
								<div v-if="scope.row.basicData.rechargeUsers == 0">0</div>
						</template>
					</el-table-column>
					
					<el-table-column sortable prop="basicData.newIncreaseEquipments" label="新增设备数" width="130">
					</el-table-column>
					<el-table-column label="留存数据" v-if="targetList[0]">
						<el-table-column v-for="(item, i) in targetList[0].childList" :key="i" v-if="item.checked" :prop="item.code" :label="item.title" >
							<template slot-scope="scope">
								<div v-if="scope.row.keepData != null">{{scope.row.keepData[item.code]}}</div>
							</template>
						</el-table-column>					 
					</el-table-column>
					<el-table-column label="LTV数据" v-if="targetList[1]">
						<template slot="header" slot-scope="scope">
							<div>LTV数据</div>
							<el-tooltip class="item" effect="dark" content="选择日期范围内的新增设备在当日的平均付费收入" placement="top-start">
								<div><i class="el-icon-question"></i></div>
							</el-tooltip>
						</template>
						<el-table-column v-for="(item, i) in targetList[1].childList" :key="i" v-if="item.checked" :prop="item.code" :label="item.title" >
							<template slot-scope="scope">
								<div>0</div>
							</template>
						</el-table-column>					 
					</el-table-column>
				</el-table>
				<!-- 分页组件 -->
				<Pagination v-bind:child-msg="pageInfo" @callFather="page"></Pagination>
			</div>
		</el-card>		
	</div>
</template>

<script>
import Pagination from '../../components/Pagination'
import appSelect from '../../components/appSelect'
import channelSelect from '../../components/channelSelect'
import targetSelect from '../../components/targetSelect'
import * as targetTmpl from '../../components/targetTmpl'
import * as appChannelApi from '../../api/appChannelApi'

export default {
	components: {
		/**注册分页组件*/
		Pagination,
		targetSelect,
		appSelect,
		channelSelect
	},
	data() {
		return {			
			queryDto: {
				date: [],
				appId: '',
				channelId: ''
			},			
			loading: false,
			pageInfo: {
				currentPage: 1,
				pageSize: 10,
				total: 10,
				list: []
			},
			targetList: []			
		}
	},
	methods: {
		init(){
			var date = new Date();
			this.queryDto.date[1] = this.getDate(date);
			
			date.setDate(date.getDate() - 7);
			this.queryDto.date[0] = this.getDate(date);
			
		
			this.targetList = targetTmpl.getTmpl();
			this.getData();
		},
		getData(){			
			var param = {
				page: this.pageInfo.currentPage,
				pageSize: this.pageInfo.pageSize,
				beginDate: this.queryDto.date[0],
				endDate: this.queryDto.date[1]
			}
			appChannelApi.appChannelPage(param).then(response => {
				this.loading = false
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					
					this.pageInfo.list = response.data.list;
					// 分页赋值
					this.pageInfo.currentPage = response.data.pageNum;
					this.pageInfo.pageSize = response.data.pageSize;
					this.pageInfo.total = response.data.total;
				}
			}).catch(err => {
			    this.loading = false
			    this.$message.error('数据加载失败，请稍后再试！')
			})
		},
		page(param){
			this.pageInfo.currentPage = param.currentPage;
			this.pageInfo.pageSize = param.pageSize;
			this.getData();	
		},
		addLtvTendency(){
			if(!this.queryDto.appId) {
				 this.$message.error('请选择游戏')
			}
		},
		selectTarget(targetList){
			this.targetList = targetList;
		}
		
	},	
	created() {
		this.init();
	}	  
}
</script>

<style scoped>
.user-search {
  margin-top: 20px;
}
.userRole {
  width: 100%;
}
.cell {
	text-align: center !important
}
.el-table th div {
	line-height: 12px !important;
}
.el-table .cell, .el-table th div {
	padding: 0px 4px !important;
}
</style>

 
 