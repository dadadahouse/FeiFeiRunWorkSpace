<template>
	<div>		
		<!-- 搜索筛选 -->
		<el-form :inline="true" class="user-search">
					
		</el-form>
		
		<el-card class="box-card">
			<div slot="header" class="clearfix">
				<span>用户管理</span>				
			</div>
			<div class="text item">
				<!--列表-->
				<el-table :data="pageInfo.list" highlight-current-row v-loading="loading" border element-loading-text="拼命加载中" style="width: 100%;">
					<el-table-column :fixed="true" sortable prop="userName" label="登录账户">
					</el-table-column>	
					<el-table-column :fixed="true" sortable prop="realName" label="联系人">
					</el-table-column>	
					<el-table-column :fixed="true" sortable prop="localIp" label="最后登录的内网IP" width="170">
					</el-table-column>	
					<el-table-column :fixed="true" sortable prop="remoteIp" label="最后登录的公网IP" width="170">
					</el-table-column>
					<el-table-column :fixed="true" sortable prop="loginDay" label="最后登录时间">
					</el-table-column>
					<el-table-column :fixed="true" sortable prop="email" label="邮箱">
					</el-table-column>	
					<el-table-column :fixed="true" sortable prop="phone" label="联系电话">
					</el-table-column>	
					<el-table-column :fixed="true" sortable prop="userQQ" label="QQ">
					</el-table-column>	
					<el-table-column :fixed="true" sortable prop="loginStauts" label="状态">
						<template slot-scope="scope">
							<div v-if="scope.row.loginStauts == 0">正常</div>
							<div v-if="scope.row.loginStauts != 0">拉黑</div>
						</template>				
					</el-table-column>
					<el-table-column :fixed="true" sortable prop="loginStauts" label="操作" width="300">
						<template slot-scope="scope">
							<el-button size="mini" type="danger" v-if="scope.row.loginStauts == 0" @click="loginStauts(scope.row)">拉黑</el-button>
							<el-button size="mini" type="danger" v-if="scope.row.loginStauts != 0" @click="loginStauts(scope.row)">启用</el-button>
							<el-button size="mini" @click="getRoleList(scope.row)" type="danger">数据权限</el-button>
							<el-button size="mini" type="danger" @click="getAppList(scope.row)">关联游戏</el-button>
						</template>
					</el-table-column>	
				</el-table>
				<!-- 分页组件 -->
				<Pagination v-bind:child-msg="pageInfo" @callFather="page"></Pagination>
			</div>
		</el-card>
		
		<!-- 数据权限 -->
		<el-dialog title="数据权限" :visible.sync="roleDialog.dialogVisible" width="30%" @click='roleDialog.dialogVisible = false'>
			<el-checkbox-group v-model="roleDialog.checkRoleList">
				<el-checkbox v-for="item in roleDialog.roleList" border :label="item.roleId">	
					{{item.roleName}}
				</el-checkbox>
			</el-checkbox-group>
			<div slot="footer" class="dialog-footer">
				<el-button @click='roleDialog.dialogVisible = false'>取消</el-button>
				<el-button type="primary" :loading="loading" class="title" @click="authRole">保存</el-button>
		  </div>
		</el-dialog>
		
		
		<!-- 关联游戏 -->
		<el-dialog title="关联游戏" :visible.sync="appDialog.dialogVisible" width="30%" @click='appDialog.dialogVisible = false'>
					
			<el-transfer filterable filter-placeholder="请输入游戏名称" 
				:data="appDialog.appList" v-model="appDialog.checkAppList"
				:titles="['所有游戏', '已选游戏']" :format="appDialog.defaultFormat" :props="appDialog.defaultProps">
			</el-transfer>
			<div slot="footer" class="dialog-footer">
				<el-button @click='appDialog.dialogVisible = false'>取消</el-button>
				<el-button type="primary" :loading="loading" class="title" @click="authApp">保存</el-button>
		  </div>
		</el-dialog>
	</div>
</template>

<script>
import Pagination from '../../components/Pagination'
import * as userApi from '../../api/userApi'
import $echarts from 'echarts'

export default {
	components: {
		/**注册组件*/
		Pagination
	},
	data() {
		return {
			loading: false,	
			pageInfo: {
				currentPage: 1,
				pageSize: 10,
				total: 10,
				list: []
			},
			roleDialog: {
				dialogVisible: false,
				userId: 0,
				roleList: [],
				checkRoleList:[]
			},
			appDialog: {
				defaultProps: {
					key: 'appId',
					label: 'appName'
				},
				defaultFormat: {
					noChecked: '${total}',
					hasChecked: '${checked}/${total}'
				},
				dialogVisible: false,
				userId: 0,
				appList: [],
				checkAppList:[]
			}			
		}
	},
	methods: {
		init(){
			this.getData();
		},
		getData(){
			var param = {
				page: this.pageInfo.currentPage,
				pageSize: this.pageInfo.pageSize
			};
			this.loading = true;
			userApi.page(param).then(response => {
				this.loading = false
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.pageInfo.list = response.data.list;
					// 分页赋值
					this.pageInfo.currentPage = response.data.pageNum;
					this.pageInfo.pageSize = response.data.pageSize;
					this.pageInfo.total = response.data.total;
				}
			}).catch(err => {
				this.loading = false
				this.$message.error('数据加载失败，请稍后再试！')
			})
		},
		page(param){
			this.pageInfo.currentPage = param.currentPage;
			this.pageInfo.pageSize = param.pageSize;
			this.getData();	
		},
		loginStauts(row) {	
			var loginStauts = row.loginStauts == 0 ? 1 : 0;
			var msg = loginStauts == 0 ? '启用': '拉黑';
			this.$confirm('是否确认' + msg + '该用户?', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				var param = {
					userId: row.userId,
					loginStauts: loginStauts
				};
				this.loading = true;
				userApi.loginStauts(param).then(response => {
					this.loading = false
					if (response.code != 0) {
						this.$message.info(response.msg);
					} else {
						this.$message.success('操作成功！')
						this.getData();
					}
				}).catch(err => {
					this.loading = false
					this.$message.error('数据加载失败，请稍后再试！')
				});
			}).catch(() => {
				this.$message.info('已取消操作！')
			});
			
		},
		getRoleList(row) {
			this.roleDialog.userId = row.userId;
			this.roleDialog.checkRoleList = [];
			
			this.roleDialog.dialogVisible = true;
			this.loading = true;
			userApi.roleList(this.roleDialog.userId).then(response => {
				this.loading = false;
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.roleDialog.roleList = response.data;	
					this.roleDialog.roleList.forEach((e) => {
						if(e.check) {
							this.roleDialog.checkRoleList.push(e.roleId);
						}
					});
				}
			}).catch(err => {
				this.loading = false
				this.$message.error('数据加载失败，请稍后再试！')
			})
		},
		authRole(){
			var param = {
				userId: this.roleDialog.userId,
				roleList: this.roleDialog.checkRoleList
			};
			this.loading = true;
			userApi.authRole(param).then(response => {
				this.loading = false;
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.roleDialog.dialogVisible = false;
					this.$message.success('操作成功！')
				}
			}).catch(err => {
				console.log(err);
				this.loading = false
				this.$message.error('数据加载失败，请稍后再试！')
			})
		},		
		getAppList(row) {
			this.appDialog.userId = row.userId;
			this.appDialog.checkAppList = [];
			
			this.appDialog.dialogVisible = true;
			this.loading = true;
			userApi.appList(this.appDialog.userId).then(response => {
				this.loading = false;
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.appDialog.appList = response.data;	
					this.appDialog.appList.forEach((e) => {
						if(e.check) {
							this.appDialog.checkAppList.push(e.appId);
						}
					});
				}
			}).catch(err => {
				this.loading = false
				this.$message.error('数据加载失败，请稍后再试！')
			})
		},
		authApp(){
			var param = {
				userId: this.appDialog.userId,
				appList: this.appDialog.checkAppList
			};
			this.loading = true;
			userApi.authApp(param).then(response => {
				this.loading = false;
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.appDialog.dialogVisible = false;
					this.$message.success('操作成功！')
				}
			}).catch(err => {
				console.log(err);
				this.loading = false
				this.$message.error('数据加载失败，请稍后再试！')
			})
		}
	},	
	created() {
		this.init();
	}	  
}
</script>

<style scoped>
.user-search {
  margin-top: 20px;
}
.userRole {
  width: 100%;
}
.customDialog {
	width: 30%;
	min-width: 500px;
}
</style>

<style>
.customDialog {
	width: 30%;
	min-width: 500px;
}
.el-table th div {
	line-height: 12px !important;
}
.el-table .cell, .el-table th div {
	padding: 0px 4px !important;
	text-align: center !important
}
</style>

 
 