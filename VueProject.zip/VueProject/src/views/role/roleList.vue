<template>
	<div>		
		<!-- 搜索筛选 -->
		<el-form :inline="true" class="user-search">
			<el-form-item>
				<el-button type="primary" icon="el-icon-circle-plus-outline" @click="openAdd()">新增</el-button>				
			</el-form-item>			
		</el-form>	
		
		<el-card class="box-card">
			<div slot="header" class="clearfix">
				<span>角色管理</span>				
			</div>
			<div class="text item">
				<!--列表-->
				<el-table :data="roleList" highlight-current-row v-loading="loading" border element-loading-text="拼命加载中" style="width: 50%;margin-bottom: 30px;">
					<el-table-column :fixed="true" sortable prop="roleName" label="角色名称">
					</el-table-column>
					<el-table-column :fixed="true" sortable prop="remark" label="备注">
					</el-table-column>
					<el-table-column :fixed="true" sortable label="操作" width="200">
						<template slot-scope="scope">
							<el-button size="mini" type="danger" @click="openModify(scope.row)">编辑</el-button>
							<el-button size="mini" type="danger" @click="getRoleMenu(scope.row)">权限设置</el-button>
						</template>
					</el-table-column>
				</el-table>					
			</div>
		</el-card>
		
		<!-- 角色权限 -->
		<el-dialog title="角色权限" :visible.sync="roleMenuDialog.dialogVisible" width="20%" @click='roleMenuDialog.dialogVisible = false'>
			<el-tree ref="menu-tree" :data="roleMenuDialog.roleMenuList" :default-checked-keys="roleMenuDialog.checkMenuList" :props="roleMenuDialog.defaultProps" node-key="id" show-checkbox></el-tree>

			<div slot="footer" class="dialog-footer">
				<el-button @click='roleMenuDialog.dialogVisible = false'>取消</el-button>				
				<el-button type="primary" :loading="loading" class="title" @click="installAuth">保存</el-button>
			</div>
		</el-dialog>
		
		<!-- 新增角色 -->
		<el-dialog :title="roleDialog.title" :visible.sync="roleDialog.dialogVisible" width="30%" @click='roleDialog.dialogVisible = false'>
			<el-form :model="roleDialog.dto" class="user-search" label-width="20%">				
				<el-form-item label="角色名称" prop="roleName">
					<el-input style="width:58%" v-model="roleDialog.dto.roleName" placeholder="角色名称"></el-input>
				</el-form-item>
				<el-form-item label="备注" prop="remark">
					<el-input type="textarea" style="width:58%" v-model="roleDialog.dto.remark" placeholder="备注"></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click='roleDialog.dialogVisible = false'>取消</el-button>
				<el-button type="primary" :loading="loading" class="title" v-if="roleDialog.type == 0" @click="addRole">新增</el-button>
				<el-button type="primary" :loading="loading" class="title" v-if="roleDialog.type == 1" @click="modifyRole">保存</el-button>
			</div>
		</el-dialog>
	</div>
</template>

<script>
import Pagination from '../../components/Pagination'
import * as roleApi from '../../api/roleApi'

export default {
	components: {
		/**注册组件*/
		Pagination
	},
	data() {
		return {			
			loading: false,	
			roleList: [],
			roleDialog: {
				dialogVisible: false,
				title: '新增',
				type: 0,
				dto: {
					roleId: 0,
					roleName: '',
					remark: ''
				}
			},
			roleMenuDialog: {
				dialogVisible: false,
				defaultProps:{
					children: 'childList',
					label: 'menuName'
				},
				roleMenuList:[],
				checkMenuList:[],
				roleId: 0
			},
		}
	},
	methods: {
		init(){
			this.getData();
		},
		getData(){
			this.loading = true;
			roleApi.roleList().then(response => {
				this.loading = false
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.roleList = response.data;				
				}
			}).catch(err => {
				this.loading = false
				this.$message.error('数据加载失败，请稍后再试！')
			})
		},
		getRoleMenu(row) {
			this.roleMenuDialog.dialogVisible = true;
			this.roleMenuDialog.roleId = row.id;
			roleApi.roleMenu(this.roleMenuDialog.roleId).then(response => {
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.roleMenuDialog.roleMenuList = response.data.menuList;	
					this.roleMenuDialog.checkMenuList = response.data.checkMenuList;	
					
				}
			}).catch(err => {				
				this.$message.error('数据加载失败，请稍后再试！')
			})
		},
		installAuth(){
			this.loading = true;
			var param = {
				roleId: this.roleMenuDialog.roleId,
				menuList: this.$refs['menu-tree'].getCheckedKeys()
			}
			
			roleApi.authRole(param).then(response => {
				this.loading = false;
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.roleMenuDialog.dialogVisible = false;
					this.$message.success('操作成功！')					
				}
			}).catch(err => {	
				this.loading = false;			
				this.$message.error('数据加载失败，请稍后再试！')
			})
		},
		openAdd(){
			this.roleDialog.title = "新增";
			this.roleDialog.type = 0;
			this.roleDialog.dialogVisible = true;
		},
		addRole(){
			this.loading = true;
			var param = {
				roleName: this.roleDialog.dto.roleName,
				remark: this.roleDialog.dto.remark
			}
			
			roleApi.addRole(param).then(response => {
				this.loading = false;
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.roleDialog.dialogVisible = false;
					this.getData();
					this.$message.success('新增角色成功！')					
				}
			}).catch(err => {	
				this.loading = false;			
				this.$message.error('数据加载失败，请稍后再试！')
			})
		},
		openModify(row){
			this.roleDialog.title = "编辑";
			this.roleDialog.type = 1;
			this.roleDialog.dialogVisible = true;
			this.roleDialog.dto = {
				roleId: row.id,
				roleName: row.roleName,
				remark: row.remark
			}
			
		},
		modifyRole(){
			this.loading = true;
			var param = {
				roleId: this.roleDialog.dto.roleId,
				roleName: this.roleDialog.dto.roleName,
				remark: this.roleDialog.dto.remark
			}
			
			roleApi.modifyRole(param).then(response => {
				this.loading = false;
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.roleDialog.dialogVisible = false;
					this.getData();
					this.$message.success('角色信息编辑成功！')					
				}
			}).catch(err => {	
				this.loading = false;			
				this.$message.error('数据加载失败，请稍后再试！')
			})
		}
	},	
	created() {
		this.init();
	}	  
}
</script>

<style scoped>
.user-search {
  margin-top: 20px;
}
.userRole {
  width: 100%;
}
.customDialog {
	width: 30%;
	min-width: 500px;
}
</style>

<style>
.customDialog {
	width: 30%;
	min-width: 500px;
}
.el-table th div {
	line-height: 12px !important;
}
.el-table .cell, .el-table th div {
	padding: 0px 4px !important;
	text-align: center !important
}
</style>

 
 