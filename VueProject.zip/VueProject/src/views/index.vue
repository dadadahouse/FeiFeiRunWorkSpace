<template>  
	<el-container class="index-con">
		<el-aside :class="showclass">
			<nav_menu></nav_menu>
		</el-aside>
		<el-container class="main-con">
			<el-header class="index-header">
				<navcon></navcon>
			</el-header>
			<el-main clss="index-main">
				<router-view></router-view>
			</el-main>
		</el-container>
	</el-container>
</template>
<script>
// 导入组件
import navcon from '../components/navcon.vue'
import nav_menu from '../components/menu.vue'
export default {
	name: 'index',
	data() {
		return {
			showclass: 'asideshow',
			showtype: false
		}
	},
	components: {
		navcon,
		nav_menu
	},
	methods: {},
	created() {
		// 监听
		this.$root.Bus.$on('toggle', value => {
			if (value) {
				this.showclass = 'asideshow'
			} else {
				setTimeout(() => {
					this.showclass = 'aside'
				}, 300)
			}
		})
	},
	beforeUpdate() {},	
	beforeMount() {
		// 挂载前状态(里面是操作)
		this.$message({
			message: '登录成功',
			type: 'success'
		})
	}
}
</script>
<style >
.index-con {
  height: 100%;
  width: 100%;
  box-sizing: border-box;
}

.aside {
  width: 64px !important;
  height: 100%;
  background-color: #334157;
  margin: 0px;
}
.asideshow {
  width: 240px !important;
  height: 100%;
  background-color: #334157;
  margin: 0px;
}
.index-header,
.index-main {
  padding: 0px;
  border-left: 2px solid #333;
}
</style>
