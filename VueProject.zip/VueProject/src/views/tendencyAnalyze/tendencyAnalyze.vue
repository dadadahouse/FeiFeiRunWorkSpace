<template>
	<div>
		<div>
			<div class="analyze">
				<i class="el-icon-plus icon" @click="tendencyDialogVisible = true"></i>			
			</div>
			<div :id="'chart-container-' + i" class="analyze-chart" v-for="(item, i) of historyList">
				<div class="close-icon" @click="closeChart(i)"><i class="el-icon-circle-close-outline"></i></div>
				<div class="canvas-container"></div>
			</div>
		</div>

		<el-dialog title="趋势模板选择" :visible.sync="tendencyDialogVisible" width="30%">
			<el-form :model="tendencyDto" ref="addTendency"  class="user-search" label-width="20%">
				<el-form-item label="模板" prop="tendencyId">
					<tendencySelect v-bind:query-dto="tendencyDto"></tendencySelect>
				</el-form-item>	
				<el-form-item label="图表" prop="tendencyId">
					<el-select v-model="tendencyDto.type" placeholder="请选择">
						<el-option key="0" label="LTV趋势图" value="0"></el-option>
						<el-option key="1" label="ROI趋势图" value="1"></el-option>
					</el-select>
				</el-form-item>	
				<el-form-item label="起始日期" prop="tendencyId">
					 <el-date-picker v-model="tendencyDto.date" value-format="yyyy-MM-dd" type="date" placeholder="选择起始日期"></el-date-picker>
				</el-form-item>
				<el-form-item label="游戏" prop="appId">
					<appSelect v-bind:query-dto="tendencyDto"></appSelect>
				</el-form-item>	
				<el-form-item label="渠道" prop="channelId">
					<channelSelect v-bind:query-dto="tendencyDto"></channelSelect>
				</el-form-item>	
				<el-form-item label="设备成本" prop="deviceCost">
					<el-input style="width:48%" v-model="tendencyDto.deviceCost" placeholder="设备成本(若不填则取投放数据)"></el-input>
				</el-form-item>
			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="tendencyDialogVisible = false">取 消</el-button>
				<el-button v-loading="tendencyDto.btnLoading" type="primary" @click="analyze">确 定</el-button>
			</span>
		</el-dialog>
	</div>
</template>

<script>
import tendencySelect from '../../components/tendencySelect'
import appSelect from '../../components/appSelect'
import channelSelect from '../../components/channelSelect'
import $echarts from 'echarts'
import * as analyzeApi from '../../api/analyzeApi'

export default {
	components: {
		tendencySelect,
		appSelect,
		channelSelect
	},
	data() {
		return {
			tendencyDialogVisible: false,
			tendencyDto: {
				btnLoading:false,
				tendencyId: '',
				appId: '',
				channelId: '',
				date: '',
				type: '',
				deviceCost: ''
			},
			historyList: []
		}
	},
	methods: {
		init(){	
			var date = new Date();			
			date.setDate(date.getDate() - 1);
			this.tendencyDto.date = this.getDate(date);
			var content = sessionStorage.getItem("historyChart");
			if(content){
				var $this = this;		
				$this.historyList = JSON.parse(content);
				setTimeout(function(){
					$this.historyList.forEach(function(item, i) {
						let $chart = $echarts.init(document.querySelector('#chart-container-' + i + " .canvas-container"));					
						
						$chart.setOption(item);
					});			
				}, 300);
			}
		},
		analyze(){
			this.tendencyDto.btnLoading = true;
			var param = {
				tendencyId: this.tendencyDto.tendencyId,
				appId: this.tendencyDto.appId,
				channelId: this.tendencyDto.channelId,
				date: this.tendencyDto.date,
				deviceCost: this.tendencyDto.deviceCost
			}
			var fun = this.tendencyDto.type == 0 ? analyzeApi.ltv : analyzeApi.roi;
			fun(param).then(response => {
				this.tendencyDto.btnLoading = false
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {					
					this.historyList.unshift(response.data);				
					
					sessionStorage.setItem("historyChart", JSON.stringify(this.historyList));
					
					this.tendencyDialogVisible = false;
					this.init();
				}
			}).catch(error => {
				console.error(error);
				this.tendencyDto.btnLoading = false;
				this.$message.error('数据加载失败，请稍后再试！')
			})
		},
		closeChart(i){
			this.$confirm('确认删除, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
			}).then(() => {
					this.historyList.splice(i, 1);
					sessionStorage.setItem("historyChart", JSON.stringify(this.historyList));
					this.init();
					this.$message.success('删除成功！');
			}).catch(() => {
					this.$message.info('操作已取消！');
			});
			
		}
	},	
	created() {
		this.init();
	}	  
}
</script>

<style scoped>
.analyze,.analyze-chart {
    border: 1px dashed #409EFF;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
	display: inline-block;
    outline: none;
	margin: 5px;	
}
.analyze-chart, .canvas-container {
	width: 700px;
    height: 400px;
}
.close-icon{
	float: right;
    position: absolute;
    right: -7px;
    top: -7px;
}
.analyze .icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
}
</style>

 
 