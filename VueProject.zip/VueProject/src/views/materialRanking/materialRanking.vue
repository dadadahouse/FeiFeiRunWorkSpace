<template>
	<div>		
		<!-- 搜索筛选 -->
		<el-form :inline="true" :model="queryDto" class="user-search">
			<el-form-item label="">
				<el-date-picker v-model="queryDto.date" type="daterange"
				  align="right"  unlink-panels value-format="yyyy-MM-dd"
				  range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
				</el-date-picker>
			</el-form-item>	
			<el-form-item label="">
				<mediaSelect v-bind:query-dto="queryDto"></mediaSelect>
			</el-form-item>	
			<el-form-item label="">
				<appSelect v-bind:query-dto="queryDto"></appSelect>
			</el-form-item>	
			<el-form-item label="">
				<channelSelect v-bind:query-dto="queryDto"></channelSelect>
			</el-form-item>					
			<el-form-item>
				<el-button type="primary" @click="getData" icon="el-icon-search">搜索</el-button>				
			</el-form-item>			
		</el-form>
		
		<el-card class="box-card">
			<div slot="header" class="clearfix">
				<span>素材排行榜</span>				
			</div>
			<div class="text item">
				<!--列表-->
				<el-table :data="list" highlight-current-row  height="300" v-loading="loading" border element-loading-text="拼命加载中" style="width: 100%;">
					<el-table-column sortable prop="cId" label="素材标识">
					</el-table-column>
					<el-table-column label="素材内容">
						<template slot-scope="scope">
								<el-popover placement="right" trigger="hover" width="400">
									<img  :src="MATERIAL_ROOT + scope.row.image" style="width:100%"/>
									<img slot="reference" :src="MATERIAL_ROOT + scope.row.image" class="thumbnail"/>
								</el-popover>
						</template>
					</el-table-column>
					<el-table-column prop="mediaName" label="媒体">
					</el-table-column>	
					<el-table-column prop="appName" label="游戏">
					</el-table-column>	
					<el-table-column prop="channelName" label="渠道">
					</el-table-column>					
					<el-table-column sortable prop="showCount" label="展示">
					</el-table-column>
					<el-table-column sortable prop="clickCount" label="点击">
					</el-table-column>
					<el-table-column sortable prop="convertCount" label="转化">
					</el-table-column>
					<el-table-column sortable prop="cost" label="消耗(单位:元)">
					</el-table-column>						
				</el-table>
			</div>
		</el-card>		
	</div>
</template>

<script>
import appSelect from '../../components/appSelect'
import channelSelect from '../../components/channelSelect'
import mediaSelect from '../../components/mediaSelect'
import * as materialRankingApi from '../../api/materialRankingApi'

export default {
	components: {
		appSelect,
		mediaSelect,
		channelSelect
	},
	data() {
		return {			
			queryDto: {
				date: [],
				appId: '',
				channelId: '',
				mediaId: ''
			},			
			loading: false,
			list:[]			
		}
	},	
	methods: {
		init(){
			var date = new Date();
			this.queryDto.date[1] = this.getDate(date);

			this.queryDto.date[0] = this.getDate(date);
			this.getData();			
		},
		getData(){
			var param = {
				appId: this.queryDto.appId,
				channelId: this.queryDto.channelId,
				mediaId: this.queryDto.mediaId,
				startTime: this.queryDto.date[0],
				endTime: this.queryDto.date[1]
			}
			materialRankingApi.ranking(param).then(response => {
				this.loading = false
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.list = response.data;
				}
			}).catch(error => {
				console.error(error);
				this.loading = false;
				this.$message.error('数据加载失败，请稍后再试！')
			})
		}		
	},	
	created() {
		this.init();
	}	  
}
</script>

<style scoped>
.user-search {
  margin-top: 20px;
}
.userRole {
  width: 100%;
}
.cell {
	text-align: center !important
}

.thumbnail{
	width: 150px !important;
	height: 100px !important;
}
</style>

 
 