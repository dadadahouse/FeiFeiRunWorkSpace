/**
 * 时间戳
 * @param {*} timestamp  时间戳
 */
export const getDateTime = (date) => {
	if(date == null) {
		return null;
	}
	
    let year = date.getFullYear();
    let month = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    let day = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate());
    
    let hour =
        (date.getHours() < 10 ? '0' + date.getHours() : date.getHours());
    let minute =
        (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes());
    let second =
        date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();
    return year + '-' + month + '-' + day + ' ' + hour + ':' +  minute + ':' + second;
};


export const getDate = (date) => {
    if(date == null) {
		return null;
	}
	
	let year = date.getFullYear();
    let month = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    let day = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate());
    return year + '-' + month + '-' + day;
};

export const isBlank = (value) => {
	if (value !== null && value !== 'undefined' && value !== undefined && (value + '').length > 0) {
		return false;
	} else {
		return true;
	}
}


/**
 * 存储localStorage
 */
const setStore = (name, content) => {
    if (!name) return;
    if (typeof content !== 'string') {
        content = JSON.stringify(content);
    }
    window.localStorage.setItem(name, content);
}

/**
 * 获取localStorage
 */
const getStore = name => {
    if (!name) return;
    return window.localStorage.getItem(name);
}

/**
 * 删除localStorage
 */
const removeStore = name => {
    if (!name) return;
    window.localStorage.removeItem(name);
}

/**
 * 设置cookie
 **/
function setCookie(name, value, day) {
    let date = new Date();
    date.setDate(date.getDate() + day);
    document.cookie = name + '=' + value + ';expires=' + date;
};

/**
 * 获取cookie
 **/
function getCookie(name) {
    let reg = RegExp(name + '=([^;]+)');
    let arr = document.cookie.match(reg);
    if (arr) {
        return arr[1];
    } else {
        return '';
    }
};

/**
 * 删除cookie
 **/
function delCookie(name) {
    setCookie(name, null, -1);
};

/**
 * 导出 
 **/
export {	
    setStore,
    getStore,
    removeStore,
    setCookie,
    getCookie,
    delCookie
}