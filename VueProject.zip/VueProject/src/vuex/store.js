import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);
// 登录验证
export default new Vuex.Store({
    state: {
        user: false
    },
    mutations: {
        // 登录
        login(state, userInfo) {
            state.user = true;
            localStorage.setItem("userInfo", JSON.stringify(userInfo));
        },
        // 退出
        logout(state) {
            state.user = false;
            localStorage.setItem("userInfo", "");
        }
    }
})