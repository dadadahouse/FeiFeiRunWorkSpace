import { $axios  } from './axiosApi';

/** 趋势分析*/
/**分页查询*/
export const page = (params) => { return $axios.get("/tendency/page", params) };


/**添加ltv趋势分析*/
export const addLtv = (params) => { return $axios.post("/tendency/ltv", params) };
