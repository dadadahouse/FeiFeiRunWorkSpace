import { $axios  } from './axiosApi';

/** 角色信息列表*/
export const roleList = (param) => { return $axios.get("/role/list", param) };


export const roleMenu = (roleId) => { return $axios.get("/role/menu/" + roleId, {}) };


export const authRole = (param) => { return $axios.post("/role/auth", param) };


export const addRole = (param) => { return $axios.post("/role/add", param) };


export const modifyRole = (param) => { return $axios.post("/role/modify", param) };