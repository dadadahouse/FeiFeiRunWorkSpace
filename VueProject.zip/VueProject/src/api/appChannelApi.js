import { $axios  } from './axiosApi';

/** 游戏渠道数据分析*/

/**分页查询*/
export const appChannelPage = (params) => { return $axios.get("/appChannel/page", params) };
