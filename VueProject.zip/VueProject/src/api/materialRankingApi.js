import { $axios  } from './axiosApi';

/** 素材排行榜*/
export const ranking = (params) => { return $axios.get("/material/ranking", params) };
