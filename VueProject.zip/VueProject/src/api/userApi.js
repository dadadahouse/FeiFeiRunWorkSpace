import { $axios  } from './axiosApi';

/** 用户信息列表*/
export const page = (param) => { return $axios.get("/user/list", param) };

/**用户角色*/
export const roleList = (userId) => { return $axios.get("/user/roleList/" + userId, {}) };

/**授权*/
export const authRole = (param) => { return $axios.post("/user/authRole", param) };

/**用户状态*/
export const loginStauts = (param) => { return $axios.post("/user/loginStauts", param) };

/**用户关联的游戏*/
export const appList = (userId) => { return $axios.get("/user/appList/" + userId, {}) };

/**修改关联的游戏*/
export const authApp = (param) => { return $axios.post("/user/authApp", param) };
