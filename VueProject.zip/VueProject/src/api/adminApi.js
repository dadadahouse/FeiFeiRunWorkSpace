import { $axios  } from './axiosApi';

/** 登录*/
export const login = (param) => { return $axios.post("/login", param) };

/**获取登录用户菜单*/
export const menuList = () => { return $axios.get("/login/menu", {}) };

/**修改密码*/
export const modifyPassword = (param) => { return $axios.post("/login/password", param) };