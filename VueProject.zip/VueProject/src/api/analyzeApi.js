import { $axios  } from './axiosApi';

/** 趋势分析*/
export const ltv = (params) => { return $axios.post("/analyze/ltv", params) };
export const roi = (params) => { return $axios.post("/analyze/roi", params) };
