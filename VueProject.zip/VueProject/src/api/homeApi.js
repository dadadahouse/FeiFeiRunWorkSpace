import { $axios  } from './axiosApi';


/**获取平台基础数据*/
export const getBasic = () => { return $axios.get("/home/basic", {}) };

/**今日游戏基础数据*/
export const appBasic = (param) => { return $axios.get("/home/appBasic", param) };

/**自定义ROI面板*/
export const definedRoi = (param) => { return $axios.get("/home/definedRoi", param) };
