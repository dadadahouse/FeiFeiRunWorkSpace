import axios from 'axios';


const getToken  = ()  => {
	var userInfo = localStorage.getItem("userInfo");
	if(userInfo) {
		var data = JSON.parse(userInfo);
		return data.token;
	}
	return null;
}
axios.defaults.headers.common['Authorization'] = getToken();

export const $axios = {
	get(url, params) {
		console.log("1" + new Date());
		return axios.get(process.env.API_ROOT + url, {params: params })
			.then(res => res.data);
	},
	delete(url, params) {
		return axios.delete(process.env.API_ROOT + url, {params: params })
			.then(res => res.data);
	},
	post(url, params) {
		return axios.post(process.env.API_ROOT + url, params)
				.then(res => res.data);
	},
	put(url, params) {
		return axios.put(process.env.API_ROOT + url, params)
				.then(res => res.data);
	},
}

