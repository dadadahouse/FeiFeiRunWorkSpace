import { $axios  } from './axiosApi';

/** 组件API*/

/**游戏列表*/
export const appList = () => { return $axios.get("/component/app", {}) };

/**渠道列表*/
export const channelList = () => { return $axios.get("/component/channel", {}) };

/**趋势模板列表*/
export const tendencyList = () => { return $axios.get("/component/tendency", {}) };

/**媒体列表*/
export const mediaList = () => { return $axios.get("/component/media", {}) };
