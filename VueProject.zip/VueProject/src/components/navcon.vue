/**
* 头部菜单
*/ 
<template>
	<div>
		<el-menu class="el-menu-demo" mode="horizontal" background-color="#334157" text-color="#fff" active-text-color="#fff">
			<el-button class="buttonimg">
				<img class="showimg" :src="collapsed?imgsq:imgshow" @click="toggle(collapsed)">
			</el-button>
			<el-submenu index="2" class="submenu">
				<template slot="title">{{userInfo.userName}}</template>
				<el-menu-item @click="openPassword()" index="0">修改密码</el-menu-item>
				<el-menu-item @click="exit()" index="1">退出</el-menu-item>
			</el-submenu>
		</el-menu>
		
		
		<!-- 修改密码 -->
		<el-dialog title="修改密码" :visible.sync="passwordDialog.dialogVisible" width="30%" @click='passwordDialog.dialogVisible = false'>
			<el-form :model="passwordDialog.dto" class="user-search" label-width="20%">
				<el-form-item label="原密码" prop="oldPassword">
					<el-input type="password" style="width:58%" v-model="passwordDialog.dto.oldPassword" placeholder="原密码"></el-input>
				</el-form-item>
				<el-form-item label="新密码" prop="password">
					<el-input type="password" style="width:58%" v-model="passwordDialog.dto.password" placeholder="新密码"></el-input>
				</el-form-item>
				<el-form-item label="确认密码" prop="confirmPassword">
					<el-input type="password" style="width:58%" v-model="passwordDialog.dto.confirmPassword" placeholder="确认密码"></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click='passwordDialog.dialogVisible = false'>取消</el-button>
				<el-button type="primary" :loading="loading" class="title" @click="modifyPassword">保存</el-button>
			</div>
		</el-dialog>
	</div>
</template>
<script>
import * as adminApi from '../api/adminApi'
export default {
	name: 'navcon',
	data() {
		return {
			collapsed: true,
			loading: false,
			imgshow: require('../assets/img/show.png'),
			imgsq: require('../assets/img/sq.png'),
			userInfo: {},
			passwordDialog: {
				dialogVisible:false,
				dto: {
					oldPassword: '',
					confirmPassword: '',
					password: ''
				}
			}
		}
	},
	// 创建完毕状态(里面是操作)
	created() {
		this.userInfo = JSON.parse(localStorage.getItem('userInfo'))
	},
	methods: {
		// 退出登录
		exit() {
			this.$confirm('退出登录, 是否继续?', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				this.$store.commit('logout', 'false')
				this.$router.push({ path: '/login' })
			}).catch(() => {
				this.$message.info("操作已取消");
			})
		},
		openPassword(){
			this.passwordDialog.dialogVisible = true;
		},
		modifyPassword(){
			var param = {
				oldPassword: this.passwordDialog.dto.oldPassword,
				confirmPassword: this.passwordDialog.dto.confirmPassword,
				password: this.passwordDialog.dto.password				
			}
			this.loading = true;
			adminApi.modifyPassword(param).then(response => {
				this.loading = false;
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.$message.success('密码修改成功，请重新登录');
					this.$store.commit('logout', 'false');
					this.$router.push({ path: '/login' });				
				}
			}).catch(err => {
				this.loading = false;
				this.$message.error('数据加载失败，请稍后再试！')
			});
		},
		toggle(showtype) {		// 切换显示
			this.collapsed = !showtype
			this.$root.Bus.$emit('toggle', this.collapsed)
		}
	}
}
</script>
<style scoped>
.el-menu-vertical-demo:not(.el-menu--collapse) {
	border: none;
}
.submenu {
	float: right;
}
.buttonimg {
	height: 60px;
	background-color: transparent;
	border: none;
}
.showimg {
	width: 26px;
	height: 26px;
	position: absolute;
	top: 17px;
	left: 17px;
}
.showimg:active {
	border: none;
}
</style>