<template>
	<div>
		<el-button size="mini" @click="dialogVisible = true;">编辑指标</el-button>

		<el-dialog title="选择指标" :visible.sync="dialogVisible">
			<div class="target-list">				
				<div class="target" v-for="(target, i) in targetList">
					<div class="target-title">
						<el-checkbox @change="checked => targetGroupChange(checked, i)" :label="i">{{target.title}}</el-checkbox>
					</div>
					<div class="target-body">
						<ul>
							<li v-for="(item, j) in target.childList">
								<el-checkbox 
									@change="checked => targetChange(checked, i, j)" 
									v-model="item.defaultChecked ? true : item.checked" 
									:disabled="item.defaultChecked" 
									:label="item.code">
									{{item.title}}
								</el-checkbox>
							</li>
						</ul>
					</div>
				</div>				
			</div>
			<div slot="footer" class="dialog-footer">
				<el-button @click="dialogVisible = false">取 消</el-button>
				<el-button type="primary" @click="selectTarget">确 定</el-button>
			</div>
		</el-dialog>	
	</div>
</template>
<script>
import * as targetTmpl from './targetTmpl'
export default {
	name: 'targetSelect',
	data() {
		return {
			dialogVisible: false, 		/**dialog是否显示*/
			targetList: []
		}
	},
	methods: {
		init(){
			this.targetList = targetTmpl.getTmpl();
		},
		targetGroupChange(checked, i){
			this.targetList[i].childList.forEach((item) => {
				if(!item.defaultChecked){
					item.checked = checked;
				}
			});
		},
		targetChange(checked, i, j){			
			var item = this.targetList[i].childList[j];
			item.checked = checked;
		},
		selectTarget(){	
			this.dialogVisible = false;
			this.$emit('callFather', this.targetList);
		}
	},
	created() {
		this.init();
	}
}


</script>

<style>
.target-list {
	height: auto;
    max-height: 570px;
	overflow:auto;
}
.target-title .el-checkbox__label{
	color:#1964d4 !important;
}
.target-title {
	border-bottom: 1px solid #c9c9c9;
	height: 36px;
	line-height:36px;
}
.target-body {
	padding-top: 15px;
	overflow: auto;
    height: auto;
}
.target-body ul {
	list-style:none;
	padding: 0px;
	margin: 0px;
}
.target-body ul li {
	float: left;
	width: 25%;
	height: 30px;
	line-height: 30px;
}

.target-list::-webkit-scrollbar-track{
	border-radius: 3px;
	background-color: #F5F5F5;
}

.target-list::-webkit-scrollbar{
	width: 3px;
	background-color: #F5F5F5;
}

.target-list::-webkit-scrollbar-thumb{
	border-radius: 3px;
	background-color: #555;
}

</style>








