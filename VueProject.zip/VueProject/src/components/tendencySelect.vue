/**tendency选择下拉框*/
<template>
	<el-select v-model="queryDto.tendencyId" clearable filterable  placeholder="趋势模板">
		<el-option v-for="item in tendencyList" :key="item.id"  :label="item.name" :value="item.id">
		</el-option>
	</el-select>
</template>
<script>
import { tendencyList } from '../api/componentApi'
export default {
	name: 'tendencySelect',
	props: ['queryDto'],
	data() {
		return {
			tendencyList: []
		}
	},
	methods: {
		initTendency: function(){			
			tendencyList({}).then(response => {
				this.loading = false
				if (response.code != 0) {
					this.$message({
						type: 'info',
						message: response.msg
					})
				} else {
					this.tendencyList = response.data;	
				}
			}).catch(err => {
			    this.loading = false
			    this.$message.error('数据加载失败，请稍后再试！')
			})
		}
	},
	created() {
		this.initTendency();
	}
}
</script>