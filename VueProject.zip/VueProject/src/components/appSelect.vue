/**APP选择下拉框*/
<template>
	<el-select v-model="queryDto.appId" clearable filterable  placeholder="游戏名称">
		<el-option v-for="item in appList" :key="item.appId"  :label="item.appName" :value="item.appId">
		</el-option>
	</el-select>
</template>
<script>
import { appList } from '../api/componentApi'
export default {
	name: 'appSelect',
	props: ['queryDto'],
	data() {
		return {
			appList: []
		}
	},
	methods: {
		initApp: function(){			
			appList({}).then(response => {
				this.loading = false
				if (response.code != 0) {
					this.$message({
						type: 'info',
						message: response.msg
					})
				} else {
					this.appList = response.data;	
				}
			}).catch(err => {
			    this.loading = false
			    this.$message.error('数据加载失败，请稍后再试！')
			})
		}
	},
	created() {
		this.initApp();
	}
}
</script>