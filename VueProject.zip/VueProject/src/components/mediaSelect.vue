/**媒体选择下拉框*/
<template>
	<el-select v-model="queryDto.mediaId" clearable filterable  placeholder="媒体名称">
		<el-option v-for="item in mediaList" :key="item.mediaId"  :label="item.mediaName" :value="item.mediaId">
		</el-option>
	</el-select>
</template>
<script>
import { mediaList } from '../api/componentApi'
export default {
	name: 'mediaSelect',
	props: ['queryDto'],
	data() {
		return {
			mediaList: []
		}
	},
	methods: {
		initApp: function(){			
			mediaList({}).then(response => {
				this.loading = false
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					this.mediaList = response.data;	
				}
			}).catch(err => {
			    this.loading = false
			    this.$message.error('数据加载失败，请稍后再试！')
			})
		}
	},
	created() {
		this.initApp();
	}
}
</script>