var tmpl = [
	{
		title: "留存指标",
		childList: [
			{
				title: "D2",
				code: "twokeepedpri",
				defaultChecked: true,
				checked: true
			},
			{
				title: "D3",
				code: "threekeepedpri",
				defaultChecked: true,
				checked: true
			},
			{
				title: "D4",
				code: "fourkeepedpri",
				defaultChecked: true,
				checked: true
			},
			{
				title: "D5",
				code: "fivekeepedpri",
				defaultChecked: true,
				checked: true
			},
			{
				title: "D6",
				code: "sixkeepedpri",
				defaultChecked: true,
				checked: true
			},
			{
				title: "D7",
				code: "servenkeepedpri",
				defaultChecked: true,
				checked: true
			},
			{
				title: "D15",
				code: "fifteenkeepedpri",
				defaultChecked: false,
				checked: false
			},
			{
				title: "D30",
				code: "thritykeepedpri",
				defaultChecked: false,
				checked: false
			},
			{
				title: "D45",
				code: "fortyFivekeepedpri",
				defaultChecked: false,
				checked: false
			},
			{
				title: "D60",
				code: "sixtykeepedpri",
				defaultChecked: false,
				checked: false
			},
			{
				title: "D90",
				code: "ninetykeepedpri",
				defaultChecked: false,
				checked: false
			},
			{
				title: "D120",
				code: "hundredTwentykeepedpri",
				defaultChecked: false,
				checked: false
			},
			{
				title: "D150",
				code: "hundredFiftykeepedpri",
				defaultChecked: false,
				checked: false
			},
			{
				title: "D180",
				code: "hundredEightykeepedpri",
				defaultChecked: false,
				checked: false
			}
		]
	},{
		title: "LTV指标",
		childList: [
			{
				title: "LTV2",
				code: "ltv_2",
				defaultChecked: true,
				checked: true
			},
			{
				title: "LTV3",
				code: "ltv_3",
				defaultChecked: true,
				checked: true
			},
			{
				title: "LTV4",
				code: "ltv_4",
				defaultChecked: true,
				checked: true
			},
			{
				title: "LTV5",
				code: "ltv_5",
				defaultChecked: true,
				checked: true
			},
			{
				title: "LTV6",
				code: "ltv_6",
				defaultChecked: true,
				checked: true
			},
			{
				title: "LTV7",
				code: "ltv_7",
				defaultChecked: true,
				checked: true
			},
			{
				title: "LTV8",
				code: "ltv_8",
				defaultChecked: false,
				checked: false
			},
			{
				title: "LTV9",
				code: "ltv_9",
				defaultChecked: false,
				checked: false
			}
		]
	},{
		title: "ARPU指标",
		childList: [
			{
				title: "Arpu",
				code: "Arpu",
				defaultChecked: false,
				checked: false
			}
		]
	}
];

export const getTmpl = () => {
	return tmpl;
}

