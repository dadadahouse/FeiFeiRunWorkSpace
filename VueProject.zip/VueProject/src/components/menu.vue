/**
* 左边菜单
*/ 
<template>
	<el-menu default-active="2" :collapse="collapsed" v-loading="loading" collapse-transition router :default-active="$route.path" unique-opened class="el-menu-vertical-demo" background-color="#334157" text-color="#fff" active-text-color="#ffd04b">
		<div class="logobox">
			<img class="logoimg" src="../assets/img/logo.png" alt="">
		</div>
		<div v-for="item in menuList">
			<el-menu-item :key="item.id" :index="'/' + item.menuRouter" v-if="item.childList == null || item.childList.length == 0">
				<i class="iconfont" :class="item.icon"></i>
				<span slot="title">{{item.menuName}}</span>
			</el-menu-item>
			<el-submenu :key="item.id" :index="item.menuName" v-if="item.childList != null && item.childList.length > 0">
				<template slot="title">
					<i class="iconfont" :class="item.icon"></i>
					<span>{{item.menuName}}</span>
				</template>
				<el-menu-item-group>
					<el-menu-item v-for="child in item.childList" :index="'/' + child.menuRouter" :key="child.id">
						<i class="iconfont" :class="child.icon"></i>
						<span>{{child.menuName}}</span>
					</el-menu-item>
				</el-menu-item-group>
			</el-submenu>
		</div>
	</el-menu>
</template>
<script>
import * as adminApi from '../api/adminApi'
export default {
	name: 'nav_menu',
	data() {
		return {
			collapsed: false,
			menuList: [],
			loading: false
		}
	},
	methods: {
		getMenuList() {
			this.loading = true;
			adminApi.menuList().then(response => {
				this.loading = false;
				if (response.code != 0) {
					this.$message.info(response.msg);
				} else {
					if(response.data){						
						this.$message.success('登录成功');
						this.menuList = response.data;
					}
				}				
			}).catch(err => {
				this.loading = false;
				this.$message.error('数据加载失败，请稍后再试！')
			});
		}
	},
	created() {
		this.getMenuList();
		// 监听
		this.$root.Bus.$on('toggle', value => {
			this.collapsed = !value
		})
	}
}
</script>
<style>
.el-menu-vertical-demo:not(.el-menu--collapse) {
  width: 240px;
  min-height: 400px;
}
.el-menu-vertical-demo:not(.el-menu--collapse) {
  border: none;
  text-align: left;
}
.el-menu-item-group__title {
  padding: 0px;
}
.el-menu-bg {
  background-color: #1f2d3d !important;
}
.el-menu {
  border: none;
}
.logobox {
  height: 40px;
  line-height: 40px;
  color: #9d9d9d;
  font-size: 20px;
  text-align: center;
  padding: 20px 0px;
}
.logoimg {
  height: 40px;
}
</style>