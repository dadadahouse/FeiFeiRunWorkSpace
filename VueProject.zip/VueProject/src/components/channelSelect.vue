/**Channel选择下拉框*/
<template>
	<el-select :multiple="multiple" v-model="queryDto.channelId" clearable filterable  placeholder="渠道名称">
		<el-option v-for="item in channelList" :key="item.channelId"  :label="item.channelName" :value="item.channelId">
		</el-option>
	</el-select>
</template>
<script>
import { channelList } from '../api/componentApi'
export default {
	name: 'channelSelect',
	props: ['queryDto', 'multiple'],
	data() {
		return {
			channelList: []
		}
	},
	methods: {
		initChannel: function(){			
			channelList({}).then(response => {
				this.loading = false
				if (response.code != 0) {
					this.$message({
						type: 'info',
						message: response.msg
					})
				} else {
					this.channelList = response.data;	
				}
			}).catch(err => {
			    this.loading = false
			    this.$message.error('数据加载失败，请稍后再试！')
			})
		}
	},
	created() {
		this.initChannel();
	}
}
</script>