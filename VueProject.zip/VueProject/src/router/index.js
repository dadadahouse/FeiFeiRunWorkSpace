// 导入组件
import Vue from 'vue';
import Router from 'vue-router';
// 登录
import login from '@/views/login';
// 首页
import index from '@/views/index';

// 首页
import home from '@/views/home';

/**游戏渠道数据统计*/
import appChannelData from '@/views/appChannelData/appChannelData';
import tendency from '@/views/tendency/tendency';
import tendencyAnalyze from '@/views/tendencyAnalyze/tendencyAnalyze';
import materialRanking from '@/views/materialRanking/materialRanking';
import userList from '@/views/user/userList';
import roleList from '@/views/role/roleList';

// 启用路由
Vue.use(Router);

// 导出路由 
export default new Router({
    routes: [{
        path: '/',
        name: '',
        component: login,
        hidden: true,
        meta: {
            requireAuth: false
        }
    }, {
        path: '/login',
        name: '登录',
        component: login,
        hidden: true,
        meta: {
            requireAuth: false
        }
    }, {
        path: '/index',
        name: '首页',
        component: index,
        iconCls: 'el-icon-tickets',
        children: [{
            path: '/home',
            name: 'home',
            component: home,
            meta: {
                requireAuth: true
            }
        },{
            path: '/appChannelData',
            name: 'appChannelData',
            component: appChannelData,
            meta: {
                requireAuth: true
            }
        },{
            path: '/tendency',
            name: 'tendency',
            component: tendency,
            meta: {
                requireAuth: true
            }
        },{
            path: '/tendencyAnalyze',
            name: 'tendencyAnalyze',
            component: tendencyAnalyze,
            meta: {
                requireAuth: true
            }
        },{
            path: '/materialRanking',
            name: 'materialRanking',
            component: materialRanking,
            meta: {
                requireAuth: true
            }
        },{
            path: '/userList',
            name: 'userList',
            component: userList,
            meta: {
                requireAuth: true
            }
        },{
            path: '/roleList',
            name: 'roleList',
            component: roleList,
            meta: {
                requireAuth: true
            }
        }]
    }]
})