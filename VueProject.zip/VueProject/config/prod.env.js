'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_ROOT: '"http://192.168.1.252:8080/data-analyze/"',
  MATERIAL_ROOT: '"http://192.168.1.252/images/"',
}
